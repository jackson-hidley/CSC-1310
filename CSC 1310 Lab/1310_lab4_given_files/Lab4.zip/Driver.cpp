/*
NAME: Jackson Hidley
DATE: 2/19/2020
*/

#include "Song.h"
#include "Timer.h"
#include <iostream>
#include <fstream>
using namespace std;

//LOOK!!  ENTER YOUR FUNCTION PROTOTYPES HERE
Song insertionSort( Song*, int );
Song reverseBubble( Song*, int );
Song quickSort( Song*, int, int );
int partition( Song*, int, int );
void swap( Song*, Song* );

int main()
{
	Song *mySongArray;
	mySongArray = new Song[150000];
	int numSongs = 0;
	float length;
	string temp;
	
	ofstream outFile;
	ifstream inFile;

	time_t start, end;
	char filename[50];
	cout << "\n\nWhat is the name of the file with songs? (example.txt)\n";
	cin >> filename;
	inFile.open(filename);
	
	if(!inFile)
	{
		cout << "\n\nSorry, I can't open the file songs.txt\n\n";
		exit(1);
	}
	
	while(getline(inFile, temp) && numSongs != 150000)
	{
		mySongArray[numSongs].setTitle(temp);
		getline(inFile, temp);
		mySongArray[numSongs].setArtist(temp);
		inFile >> length;
		inFile.ignore();
		mySongArray[numSongs].setLength(length);
		numSongs++;
	}
	cout << "\n\nYou have created " << numSongs << " Song objects.\n\n";
	
	
	
	 //sort the songs using insertion sort and print them out to the text file sortFileInsertion.txt
	start = getTime(); //Starts timer.   
	
	*mySongArray = insertionSort( mySongArray, length ); //LOOK!!!!  CALL THE INSERTION SORT ALGORITHM HERE

	end = getTime(); //Ends timer.
	outFile.open("sortFileInsertion.txt");
	cout << "\nInsertion sort: " << totalTime(start, end) << " seconds\n\n";
	for(int x=0; x<numSongs; x++)
	{
		outFile << mySongArray[x];
	}
	outFile.close();
	
	
	
	//sort the songs in reverse order using bubble sort & print them out to the text file sortFileReverseBubble.txt
	start = getTime(); //Starts timer. 
	
	*mySongArray = reverseBubble( mySongArray, length ); //LOOK!!!!  CALL THE REVERSE BUBBLE SORT ALGORITHM HERE
	
	
	end = getTime(); //Ends timer.
	outFile.open("sortFileReverseBubble.txt");
	cout << "\nReverse bubble sort: " << totalTime(start, end) << " seconds\n\n";
	for(int x=0; x<numSongs; x++)
	{
		outFile << mySongArray[x];
	}
	outFile.close();
	
	
	
	//sort the songs with quick sort & print them out to sortFileQuick.txt44
	start = getTime(); //Starts timer. 
	
	*mySongArray = quickSort( mySongArray, 0, length );//LOOK!!!!  CALL THE QUICKSORT ALGORITHM HERE
	
	
	end = getTime(); //Ends timer.
	cout << "\nQuicksort: " << totalTime(start, end) << " seconds\n\n";
	outFile.open("sortFileQuick.txt");
	for(int x=0; x<numSongs; x++)
	{
		outFile << mySongArray[x];
	}
	outFile.close();
	
	
	delete [] mySongArray;
	return 0;
}

//LOOK!  WRITE YOUR INSERTION SORT FUNCTION HERE
Song insertionSort( Song* arry, int size )
{
	Song key;
	int j; 
	
	for( int i = 1; i < size; i++ )
	{
		key = arry[i];
		j = i - 1;
	}
	arry[ j + 1 ] = key;
	return *arry;
}

//LOOK!  WRITE YOUR REVERSE BUBBLE SORT FUNCTION HERE
Song reverseBubble( Song* arry, int size )
{
	Song temp;
	
	//max will hold the subscript of the latest element that will be compared
	for( int max = ( size - 1 ); max > 0; max-- )
	{
		for( int i = 0; i < max; i++ )
		{
			if( arry[ i ].getTitle()< arry[ i + 1 ].getTitle() )
			{
				temp = arry[ i ];
				arry[ i ] = arry[ i + 1 ];
				arry[ i + 1 ] = temp;
			}
		}
	}
	return *arry;
}

//LOOK!  WRITE YOUR RECURSIVE QUICK SORT FUNCTION HERE
Song quickSort( Song* arry, int low, int high )
{
	int pivot = 0;
	if ( low < high )
	{
	
		pivot = partition( arry, low, high ); //returns location of last element in low partition
		quickSort( arry, low, pivot-1 ); //recursively sort low partition
		quickSort( arry, pivot+1, high ); //recursively sort high partition
	}
	return *arry;
	
}


//LOOK!  WRITE YOUR PARTITION FUNCTION HERE
int partition( Song* arry, int low, int high )
{
	Song pivot, temp;
	int i = (low-1);
	bool done = false; 
	
	//pivot starts at mid
	int mid = ( low + ( high - low ) / 2 );
	pivot = arry[ high ];
	int l = low;
	int r = high;
	
		for( int j = low; j <= r; j++ )
		{
			if( arry[j].getTitle() < pivot.getTitle())
			{
				i++;
				swap( arry[i], arry[j] ); 
			}
		}
		
	return (i+1);
}

void swap(Song* one, Song* two)
{
	cout << "\nSwapping " << *one << " & " << *two;
	Song* temp;
	*temp = *one;
	*one = *two;
	*two = *temp;
}