//Course.h
//Jackson Hidley
//1/29/2020

#ifndef Course_H
#define Course_H
#include <string>
using namespace std;

	struct Course
	{
		public:
		string name;
		string locations;
		string* sect = new string[20];
		int numSec;
		int numCreditHours;
		int numCourses;
	};
	
	Course* createCourse( string, string, int, int );
	void destroyCourse( Course* myCourse );
	void printCourse( Course* myCourse );
	


#endif