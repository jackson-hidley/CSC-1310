//Course.cpp
//Jackson Hidley
//1/29/2020

#include <iostream>
#include <string>
#include "Course.h"

using namespace std;


Course* createCourse( string name, string location, int numSections, int numCreditHours )
{
	Course* myCourse;
	myCourse = new Course;
	cout << "Inside create course" << endl;
	myCourse->name = name; 
	myCourse->locations = location;
	myCourse->numCreditHours = numCreditHours;
	myCourse->numSec = numSections;
	
	return myCourse;
}
	
void destroyCourse( Course* myCourse )
{
	delete [] myCourse;
}

void printCourse( Course* myCourse )
{
		cout << "COURSE NAME:			" << myCourse->name << endl;
		cout << "COURSE LOCATION:		" << myCourse->locations << endl;
		cout << "COURSE HOURS:			" << myCourse->numCreditHours << endl;
		
		for ( int n=0; n < myCourse->numSec; n++ )
		{
			cout << "SECTION " << n+1 << ":			" << myCourse->sect[n] << endl;
		}

}